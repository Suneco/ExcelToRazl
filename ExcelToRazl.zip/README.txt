RTFM:

ExcelToRazl Script Generator - Manual.docx

=)